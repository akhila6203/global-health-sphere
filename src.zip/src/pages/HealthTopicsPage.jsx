import { Link } from "react-router-dom";
import ArrowForwardRoundedIcon from "@mui/icons-material/ArrowForwardRounded";
import HealthTopicCard from "../components/HealthTopicCard";
import { categories } from "../data/categories";

export default function HealthTopicsPage() {
  return (
    <main className="mx-auto w-[calc(100%-2rem)] max-w-[1400px] py-10 lg:w-[calc(100%-4rem)] max-md:py-7">
      <div className="mb-7 flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="text-xs font-extrabold uppercase tracking-[.18em] text-[#079da7]">Explore the health library</p>
          <h1 className="mt-2 text-3xl font-extrabold text-[#123c8c] sm:text-4xl">Browse All Health Topics</h1>
          <p className="mt-2 max-w-2xl text-sm leading-6 text-[#52647a]">Choose a health topic to explore its related articles and focused subtopics.</p>
        </div>
        <Link to="/articles/" className="inline-flex items-center gap-1 text-sm font-extrabold text-[#123c8c] transition hover:text-[#079da7]">
          View all articles <ArrowForwardRoundedIcon fontSize="small" />
        </Link>
      </div>

      <div className="grid grid-cols-3 items-stretch gap-5 max-lg:grid-cols-2 max-md:grid-cols-1">
        {categories.map((category) => (
          <HealthTopicCard key={category.slug} category={category} />
        ))}
      </div>
    </main>
  );
}
