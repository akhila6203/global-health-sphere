import { useMemo, useState } from "react";
import { useSearchParams } from "react-router-dom";
import SearchRoundedIcon from "@mui/icons-material/SearchRounded";
import ArticleCard from "./ArticleCard";
import CategorySubtopicTabs from "./CategorySubtopicTabs";
import { articles } from "../data/articles";
import { categories } from "../data/categories";
import { countries } from "../data/countries";

const selectClass =
  "w-full min-w-0 rounded-xl border border-[#dce8ed] bg-white px-4 py-3 text-sm font-semibold text-[#19314d] outline-none transition focus:border-[#079da7] focus:ring-2 focus:ring-[#079da7]/15";

export default function ArticleLibrary({
  title = "All Health Articles",
  initialCategory = "",
  lockedCategory = false,
  initialCountry = "",
  initialSource = "",
  showHeading = true,
  subtopicCategory = null,
}) {
  const [searchParams, setSearchParams] = useSearchParams();
  const [query, setQuery] = useState(searchParams.get("q") || "");
  const [category, setCategory] = useState(
    initialCategory || searchParams.get("category") || ""
  );
  const [country, setCountry] = useState(
    initialCountry || searchParams.get("country") || ""
  );
  const [source, setSource] = useState(
    initialSource || searchParams.get("source") || ""
  );
  // Keep the selected tab synced with CategorySubtopicTabs URL updates.
  const subtopic = searchParams.get("subtopic") || "";

  const activeCategory = subtopicCategory || categories.find((item) => item.slug === category);

  const visibleArticles = useMemo(() => {
    const normalizedQuery = query.trim().toLowerCase();

    return articles.filter((article) => {
      const articleCategorySlugs = article.categorySlugs || [article.categorySlug].filter(Boolean);
      const matchesCategory = !category || articleCategorySlugs.includes(category);
      const matchesCountry =
        !country ||
        (country === "Global"
          ? article.country === "Global"
          : article.country === country || article.country === "Global");
      const articleSources = article.sourceTypes || [];
      const matchesSource = !source || articleSources.includes(source);
      const searchableText = [
        article.title,
        article.excerpt,
        article.category,
        article.country,
        article.format,
        ...(article.tags || []),
      ]
        .join(" ")
        .toLowerCase();
      const matchesSearch = !normalizedQuery || searchableText.includes(normalizedQuery);

      const subtopicText = [
        article.title,
        article.excerpt,
        ...(article.tags || []),
      ]
        .join(" ")
        .toLowerCase();
      const matchesSubtopic =
        !subtopic ||
        subtopicText.includes(subtopic.toLowerCase()) ||
        subtopic.toLowerCase().split(/\s+/).some((word) => word.length > 3 && subtopicText.includes(word));

      return matchesCategory && matchesCountry && matchesSource && matchesSearch && matchesSubtopic;
    });
  }, [query, category, country, source, subtopic]);

  const updateFilter = (setter, value, key) => {
    setter(value);
    const next = new URLSearchParams(searchParams);
    if (value) next.set(key, value);
    else next.delete(key);
    if (key !== "subtopic") next.delete("subtopic");
    setSearchParams(next, { replace: true });
  };

  const resetFilters = () => {
    setQuery("");
    setCategory(initialCategory || (lockedCategory ? category : ""));
    setCountry(initialCountry || "");
    setSource(initialSource || "");
    const next = {};
    if (initialCategory) next.category = initialCategory;
    if (initialCountry) next.country = initialCountry;
    if (initialSource) next.source = initialSource;
    setSearchParams(next, { replace: true });
  };

  return (
    <section className="w-full">
      {showHeading && (
        <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
          <div>
            <p className="mb-2 text-xs font-extrabold uppercase tracking-[.18em] text-[#079da7]">
              Global Health Sphere Library
            </p>
            <h1 className="text-left text-3xl font-extrabold text-[#123c8c] md:text-4xl">
              {title}
            </h1>
          </div>
          <button
            type="button"
            onClick={resetFilters}
            className="rounded-lg bg-[#123c8c] px-4 py-2.5 text-sm font-bold text-white shadow-sm transition hover:-translate-y-0.5 hover:bg-[#079da7]"
          >
            All Articles
          </button>
        </div>
      )}

      <div className="mb-7 grid grid-cols-4 gap-3 rounded-2xl border border-[#e2ebef] bg-white p-4 shadow-[0_8px_25px_rgba(18,60,140,0.05)] max-lg:grid-cols-2 max-sm:grid-cols-1">
        <label className="relative col-span-1 flex min-w-0 items-center">
          <SearchRoundedIcon className="pointer-events-none absolute left-3 text-[#079da7]" />
          <input
            type="search"
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="Search articles or topics..."
            className={`${selectClass} pl-10`}
          />
        </label>

        {!lockedCategory ? (
          <select
            aria-label="Filter by category"
            value={category}
            onChange={(event) => updateFilter(setCategory, event.target.value, "category")}
            className={selectClass}
          >
            <option value="">All Categories</option>
            {categories.map((item) => (
              <option key={item.slug} value={item.slug}>{item.title}</option>
            ))}
          </select>
        ) : (
          <div className={`${selectClass} flex items-center bg-[#f4fafb]`}>{activeCategory?.title || "Selected category"}</div>
        )}

        <select
          aria-label="Filter by country"
          value={country}
          onChange={(event) => updateFilter(setCountry, event.target.value, "country")}
          className={selectClass}
        >
          <option value="">All Countries</option>
          <option value="Global">Global</option>
          {countries.map((item) => (
            <option key={item.slug} value={item.name}>{item.name}</option>
          ))}
        </select>

        <select
          aria-label="Filter by source"
          value={source}
          onChange={(event) => updateFilter(setSource, event.target.value, "source")}
          className={selectClass}
        >
          <option value="">All Sources</option>
          <option value="Global">Global</option>
          <option value="Public">Public</option>
          <option value="Sourced">Sourced</option>
        </select>
      </div>

      {subtopicCategory && <CategorySubtopicTabs category={subtopicCategory} />}

      <div className="mb-5 flex flex-wrap items-center justify-between gap-3">
        <p className="text-sm font-semibold text-[#52647a]">
          <span className="font-extrabold text-[#123c8c]">{visibleArticles.length}</span> articles found
        </p>
        <button
          type="button"
          onClick={resetFilters}
          className="rounded-lg px-3 py-2 text-sm font-bold text-[#079da7] transition hover:bg-[#eaf8f7]"
        >
          Clear filters
        </button>
      </div>

      {visibleArticles.length > 0 ? (
        <div className="grid grid-cols-3 gap-5 max-lg:grid-cols-2 max-md:grid-cols-1">
          {visibleArticles.map((article) => (
            <ArticleCard key={article.id} article={article} />
          ))}
        </div>
      ) : (
        <div className="rounded-2xl border border-dashed border-[#b9d5dc] bg-[#f7fbfc] px-6 py-12 text-center">
          <h2 className="mb-2 text-xl font-extrabold text-[#123c8c]">No matching articles</h2>
          <p className="text-sm text-[#52647a]">Try another search term or change the filters.</p>
          <button onClick={resetFilters} className="mt-4 rounded-lg bg-[#123c8c] px-5 py-2.5 text-sm font-bold text-white transition hover:bg-[#079da7]">
            Show all articles
          </button>
        </div>
      )}
    </section>
  );
}



// import { useMemo, useState } from "react";
// import { useSearchParams } from "react-router-dom";
// import SearchRoundedIcon from "@mui/icons-material/SearchRounded";
// import ArticleCard from "./ArticleCard";
// import CategorySubtopicTabs from "./CategorySubtopicTabs.jsx";
// import { articles } from "../data/articles";
// import { categories } from "../data/categories";
// import { countries } from "../data/countries";

// const selectClass =
//   "w-full min-w-0 rounded-xl border border-[#dce8ed] bg-white px-4 py-3 text-sm font-semibold text-[#19314d] outline-none transition focus:border-[#079da7] focus:ring-2 focus:ring-[#079da7]/15";

// export default function ArticleLibrary({
//   title = "All Health Articles",
//   initialCategory = "",
//   lockedCategory = false,
//   initialCountry = "",
//   initialSource = "",
//   showHeading = true,
//   subtopicCategory = null,
// }) {
//   const [searchParams, setSearchParams] = useSearchParams();
//   const [query, setQuery] = useState(searchParams.get("q") || "");
//   const [category, setCategory] = useState(
//     initialCategory || searchParams.get("category") || ""
//   );
//   const [country, setCountry] = useState(
//     initialCountry || searchParams.get("country") || ""
//   );
//   const [source, setSource] = useState(
//     initialSource || searchParams.get("source") || ""
//   );
//   const [subtopic, setSubtopic] = useState(searchParams.get("subtopic") || "");

//   const activeCategory = subtopicCategory || categories.find((item) => item.slug === category);

//   const visibleArticles = useMemo(() => {
//     const normalizedQuery = query.trim().toLowerCase();

//     return articles.filter((article) => {
//       const matchesCategory = !category || article.categorySlug === category;
//       const matchesCountry =
//         !country ||
//         (country === "Global"
//           ? article.country === "Global"
//           : article.country === country || article.country === "Global");
//       const articleSources = article.sourceTypes || [];
//       const matchesSource = !source || articleSources.includes(source);
//       const searchableText = [
//         article.title,
//         article.excerpt,
//         article.category,
//         article.country,
//         article.format,
//         ...(article.tags || []),
//       ]
//         .join(" ")
//         .toLowerCase();
//       const matchesSearch = !normalizedQuery || searchableText.includes(normalizedQuery);

//       const subtopicText = [
//         article.title,
//         article.excerpt,
//         ...(article.tags || []),
//       ]
//         .join(" ")
//         .toLowerCase();
//       const matchesSubtopic =
//         !subtopic ||
//         subtopicText.includes(subtopic.toLowerCase()) ||
//         subtopic.toLowerCase().split(/\s+/).some((word) => word.length > 3 && subtopicText.includes(word));

//       return matchesCategory && matchesCountry && matchesSource && matchesSearch && matchesSubtopic;
//     });
//   }, [query, category, country, source, subtopic]);

//   const updateFilter = (setter, value, key) => {
//     setter(value);
//     const next = new URLSearchParams(searchParams);
//     if (value) next.set(key, value);
//     else next.delete(key);
//     if (key !== "subtopic") next.delete("subtopic");
//     setSearchParams(next, { replace: true });
//     if (key !== "subtopic") setSubtopic("");
//   };

//   const resetFilters = () => {
//     setQuery("");
//     setCategory(initialCategory || (lockedCategory ? category : ""));
//     setCountry(initialCountry || "");
//     setSource(initialSource || "");
//     setSubtopic("");
//     const next = {};
//     if (initialCategory) next.category = initialCategory;
//     if (initialCountry) next.country = initialCountry;
//     if (initialSource) next.source = initialSource;
//     setSearchParams(next, { replace: true });
//   };

//   return (
//     <section className="w-full">
//       {showHeading && (
//         <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
//           <div>
//             <p className="mb-2 text-xs font-extrabold uppercase tracking-[.18em] text-[#079da7]">
//               Global Health Sphere Library
//             </p>
//             <h1 className="text-left text-3xl font-extrabold text-[#123c8c] md:text-4xl">
//               {title}
//             </h1>
//           </div>
//           <button
//             type="button"
//             onClick={resetFilters}
//             className="rounded-lg bg-[#123c8c] px-4 py-2.5 text-sm font-bold text-white shadow-sm transition hover:-translate-y-0.5 hover:bg-[#079da7]"
//           >
//             All Articles
//           </button>
//         </div>
//       )}

//       <div className="mb-7 grid grid-cols-4 gap-3 rounded-2xl border border-[#e2ebef] bg-white p-4 shadow-[0_8px_25px_rgba(18,60,140,0.05)] max-lg:grid-cols-2 max-sm:grid-cols-1">
//         <label className="relative col-span-1 flex min-w-0 items-center">
//           <SearchRoundedIcon className="pointer-events-none absolute left-3 text-[#079da7]" />
//           <input
//             type="search"
//             value={query}
//             onChange={(event) => setQuery(event.target.value)}
//             placeholder="Search articles or topics..."
//             className={`${selectClass} pl-10`}
//           />
//         </label>

//         {!lockedCategory ? (
//           <select
//             aria-label="Filter by category"
//             value={category}
//             onChange={(event) => updateFilter(setCategory, event.target.value, "category")}
//             className={selectClass}
//           >
//             <option value="">All Categories</option>
//             {categories.map((item) => (
//               <option key={item.slug} value={item.slug}>{item.title}</option>
//             ))}
//           </select>
//         ) : (
//           <div className={`${selectClass} flex items-center bg-[#f4fafb]`}>{activeCategory?.title || "Selected category"}</div>
//         )}

//         <select
//           aria-label="Filter by country"
//           value={country}
//           onChange={(event) => updateFilter(setCountry, event.target.value, "country")}
//           className={selectClass}
//         >
//           <option value="">All Countries</option>
//           <option value="Global">Global</option>
//           {countries.map((item) => (
//             <option key={item.slug} value={item.name}>{item.name}</option>
//           ))}
//         </select>

//         <select
//           aria-label="Filter by source"
//           value={source}
//           onChange={(event) => updateFilter(setSource, event.target.value, "source")}
//           className={selectClass}
//         >
//           <option value="">All Sources</option>
//           <option value="Global">Global</option>
//           <option value="Public">Public</option>
//           <option value="Sourced">Sourced</option>
//         </select>
//       </div>

//       {subtopicCategory && <CategorySubtopicTabs category={subtopicCategory} />}

//       <div className="mb-5 flex flex-wrap items-center justify-between gap-3">
//         <p className="text-sm font-semibold text-[#52647a]">
//           <span className="font-extrabold text-[#123c8c]">{visibleArticles.length}</span> articles found
//         </p>
//         <button
//           type="button"
//           onClick={resetFilters}
//           className="rounded-lg px-3 py-2 text-sm font-bold text-[#079da7] transition hover:bg-[#eaf8f7]"
//         >
//           Clear filters
//         </button>
//       </div>

//       {visibleArticles.length > 0 ? (
//         <div className="grid grid-cols-3 gap-5 max-lg:grid-cols-2 max-md:grid-cols-1">
//           {visibleArticles.map((article) => (
//             <ArticleCard key={article.id} article={article} />
//           ))}
//         </div>
//       ) : (
//         <div className="rounded-2xl border border-dashed border-[#b9d5dc] bg-[#f7fbfc] px-6 py-12 text-center">
//           <h2 className="mb-2 text-xl font-extrabold text-[#123c8c]">No matching articles</h2>
//           <p className="text-sm text-[#52647a]">Try another search term or change the filters.</p>
//           <button onClick={resetFilters} className="mt-4 rounded-lg bg-[#123c8c] px-5 py-2.5 text-sm font-bold text-white transition hover:bg-[#079da7]">
//             Show all articles
//           </button>
//         </div>
//       )}
//     </section>
//   );
// }


